﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Сoursework
{
    /// <summary>
    /// Логика взаимодействия для Specialties.xaml
    /// </summary>
    public partial class Specialties : Window
    {
        public Specialties()
        {
            InitializeComponent();
        }
        private void Exit(object sender, RoutedEventArgs e)
        {
            DialogResult result = (DialogResult)System.Windows.MessageBox.Show("Желаете закрыть приложение?", "Закрытие", MessageBoxButton.YesNo, MessageBoxImage.Information);
            if (result.ToString() == "Yes")
            {
                this.Close();
            }
        }

        private void Add(object sender, RoutedEventArgs e)
        {
            DialogResult result = (DialogResult)System.Windows.MessageBox.Show("Добавить данные?", "Добавление данных", MessageBoxButton.YesNo, MessageBoxImage.Information);
            if (result.ToString() == "Yes")
            {
               
            }
        }

        private void Delete(object sender, RoutedEventArgs e)
        {
            DialogResult result = (DialogResult)System.Windows.MessageBox.Show("Удалить данные?", "Удаление данных", MessageBoxButton.YesNo, MessageBoxImage.Information);
            if (result.ToString() == "Yes")
            {

            }
        }

        private void Edit(object sender, RoutedEventArgs e)
        {
            DialogResult result = (DialogResult)System.Windows.MessageBox.Show("Редактировать данные?", "Редактирование данных", MessageBoxButton.YesNo, MessageBoxImage.Information);
            if (result.ToString() == "Yes")
            {

            }
        }

        private void Search(object sender, RoutedEventArgs e)
        {
            DialogResult result = (DialogResult)System.Windows.MessageBox.Show("Произвести поиск?", "Поиск", MessageBoxButton.YesNo, MessageBoxImage.Information);
            if (result.ToString() == "Yes")
            {

            }
        }

        private void MenuItem_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            MainWindow am = new MainWindow();
            am.Show();
            this.Close();
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            List_patients lp = new List_patients();
            lp.Show();
            this.Close();
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            Visits v = new Visits();
            v.Show();
            this.Close();
        }

        private void MenuItem_Click_2(object sender, RoutedEventArgs e)
        {
            Diagnoses d = new Diagnoses();
            d.Show();
            this.Close();
        }

        private void MenuItem_Click_3(object sender, RoutedEventArgs e)
        {
            Doctors d = new Doctors();
            d.Show();
            this.Close();
        }
    }
}
