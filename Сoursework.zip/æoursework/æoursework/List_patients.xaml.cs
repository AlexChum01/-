﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Сoursework.DataModel;

namespace Сoursework
{
    /// <summary>
    /// Логика взаимодействия для List_patients.xaml
    /// </summary>
    public partial class List_patients : Window
    {
        registration_patientsContext db;
        public List_patients()
        {
            InitializeComponent();
            /*
             * Вывод данных в дата грид
             * Сделал пока с одной таблицей 
             * Просто по парам дел много,зачет был,ну я не оправдываюсь,ну еще лень перевешивает
             * При двойном щелчке в дата грид на определенного пользователя должен происходить переход на следующую форму
             * Следующая форма это карточка пациента,там будут выведены диагноз,фио пациента и т.д
             *P.S на стадии реализации,ну пока только в голове
             */            
            db = new registration_patientsContext();
            pasientSpis.ItemsSource = db.patientSpisoks.ToList();
        }

        private void Exit(object sender, RoutedEventArgs e)
        {
            DialogResult result = (DialogResult)System.Windows.MessageBox.Show("Желаете закрыть приложение?", "Закрытие", MessageBoxButton.YesNo, MessageBoxImage.Information);
            if (result.ToString() == "Yes")
            {
                this.Close();
            }
        }

        private void Add(object sender, RoutedEventArgs e)
        {
            /*
             добавление в отдельном окне
            переход на форму добавления
             */
            DialogResult result = (DialogResult)System.Windows.MessageBox.Show("Добавить данные?", "Добавление данных", MessageBoxButton.YesNo, MessageBoxImage.Information);
            if (result.ToString() == "Yes")
            {
                Manipulating_database md = new Manipulating_database();
                md.Show();
                this.Close();
            }
        }

        private void Delete(object sender, RoutedEventArgs e)
        {
            DialogResult result = (DialogResult)System.Windows.MessageBox.Show("Удалить данные?", "Удаление данных", MessageBoxButton.YesNo, MessageBoxImage.Information);
            if (result.ToString() == "Yes")
            {
                int num = Convert.ToInt32(idTxt.Text);
                var dRow = db.patientSpisoks.Where(w => w.ID == num).FirstOrDefault();
                db.patientSpisoks.Remove(dRow);
                db.SaveChanges();
                pasientSpis.ItemsSource = db.patientSpisoks.ToList();
            }
        }

        private void Edit(object sender, RoutedEventArgs e)
        {
            DialogResult result = (DialogResult)System.Windows.MessageBox.Show("Редактировать данные?", "Редактирование данных", MessageBoxButton.YesNo, MessageBoxImage.Information);
            if (result.ToString() == "Yes" || !String.IsNullOrWhiteSpace(idTxt.Text))
            {
                /* Редактирование данных по вводу id(номера карточки) данные не переносятся из дата грид 
                 * приходится вводить вручную так же не работает условие,при вводе пустого значения (номера карточки)
                 */
                int num = Convert.ToInt32(idTxt.Text);
                var eRow = db.patientSpisoks.Where(w => w.ID == num).FirstOrDefault();
                eRow.surname = surTxt.Text;
                eRow.name = namTxt.Text;
                eRow.midle_name = midTxt.Text;
                eRow.Adress = adrTxt.Text;
                eRow.Tel = telTxt.Text;
                eRow.Email = emlTxt.Text;
                eRow.NumberV = numVtxt.Text;
                db.SaveChanges();
                pasientSpis.ItemsSource = db.patientSpisoks.ToList();
            }
            /*else if (idTxt.Text==null)
            {
                idTxt.Background = Brushes.Red;
                idTxt.ToolTip = "Введите № карточки ";
            }*/
            else
            {
              
            }

        }

        private void Search(object sender, RoutedEventArgs e)
        {
            /*
             поиск на стадии реализации
             у меня просто сейчас времени маловато потому что работаю(
            нужно по WSR готовиться стрим нужно как то провести
             */
            DialogResult result = (DialogResult)System.Windows.MessageBox.Show("Произвести поиск?", "Поиск", MessageBoxButton.YesNo, MessageBoxImage.Information);
            if (result.ToString()=="Yes")
                {
                
                }
        }

        private void MenuItem_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            MainWindow am = new MainWindow();
            am.Show();
            this.Close();
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            Visits v = new Visits();
            v.Show();
            this.Close();
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            Specialties s = new Specialties();
            s.Show();
            this.Close();
        }

        private void MenuItem_Click_2(object sender, RoutedEventArgs e)
        {
            Diagnoses d = new Diagnoses();
            d.Show();
            this.Close();
        }

        private void MenuItem_Click_3(object sender, RoutedEventArgs e)
        {
            Doctors d = new Doctors();
            d.Show();
            this.Close();
        }

    }
}
