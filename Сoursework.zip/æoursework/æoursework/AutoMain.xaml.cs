﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Сoursework
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        /*
        Здесь должен быть код на авторизацию с разделением прав пользователей
        пациент после авторизации переходит на свою карточку
        врач после авторизации переходит на список пациентов,так же в лист вью должны передаваться данные фио, должность,специальность.
        Хотел сделать время на футаре.
        За это время только над дизайном и поработал,от силы день-два посидел.
         */
        public MainWindow()
        {
            InitializeComponent();
            DoubleAnimation btnAn = new DoubleAnimation();
            btnAn.From = 0;
            btnAn.To = 300;
            btnAn.Duration = TimeSpan.FromSeconds(3);
            Enter.BeginAnimation(System.Windows.Controls.Button.WidthProperty, btnAn);
        }

        private void Exit(object sender, RoutedEventArgs e)
        {
            DialogResult result = (DialogResult)System.Windows.MessageBox.Show("Желаете закрыть приложение?", "Закрытие",  MessageBoxButton.YesNo, MessageBoxImage.Information);
            if (result.ToString() == "Yes")
            {
                this.Close();
            }
               
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            List_patients lp = new List_patients();
            lp.Show();
            this.Close();
        }

        
    }
}
