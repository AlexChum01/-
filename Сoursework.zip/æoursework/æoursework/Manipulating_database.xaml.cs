﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Сoursework.DataModel;

namespace Сoursework
{
    /// <summary>
    /// Логика взаимодействия для Manipulating_database.xaml
    /// </summary>
    public partial class Manipulating_database : Window
    {
        registration_patientsContext db;
        public Manipulating_database()
        {
            InitializeComponent();
        }

        private void Exit(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Cancel(object sender, RoutedEventArgs e)
        {
            List_patients lp = new List_patients();
            lp.Show();
            this.Close();
        }
        /*
         Хотел проверить условия на длину 
        на ввод почты,так и не разобрался,было бы круто если подсказали.
        Ну или разобрали эти моменты.
        Происходит добавление пользователя,проверок на пустое значение нет,значит добавление произойдет,если даже ничего не введешь.
         */

      
        private void Add(object sender, RoutedEventArgs e)
        {
        /*
            if (surname.Length < 5)
            {
                sur.ToolTip = "Это поле введено не корректно!";
                sur.Background = Brushes.Red;
            }
            else if (name.Length < 3)
            { 
            nam.ToolTip = "Это поле введено не корректно!";
            nam.Background = Brushes.Red;
            }
            else if (midle_name.Length < 3)
            {
                midl.ToolTip = "Это поле введено не корректно!";
                midl.Background = Brushes.Red;
            }
            else if (Adress.Length < 5)
            {
                adres.ToolTip = "Это поле введено не корректно!";
                adres.Background = Brushes.Red;
            }
            else if (Tel.Length < 8)
            {
                tel.ToolTip = "Это поле введено не корректно!";
                tel.Background = Brushes.Red;
            }
            else if (Email.Length < 5 || Email.Contains("@") || !Email.Contains("."))
            {
                email.ToolTip = "Это поле введено не корректно!";
                email.Background = Brushes.Red;
            }*/
            DialogResult result = (DialogResult)System.Windows.MessageBox.Show("Добавить данные?", "Добавление данных", MessageBoxButton.YesNo, MessageBoxImage.Information);
            
            if (result.ToString() == "Yes")
            {
                db = new registration_patientsContext();
                patientSpisok pS = new patientSpisok();
                pS.surname = sur.Text.Trim();
                pS.name = nam.Text.Trim();
                pS.midle_name = midl.Text.Trim();
                pS.Adress = adres.Text.Trim();
                pS.Tel = tel.Text.Trim();
                pS.Email = email.Text.Trim().ToLower();
                pS.NumberV = number.Text;
                db.patientSpisoks.Add(pS);
                db.SaveChanges();
                List_patients lp = new List_patients();
                lp.Show();
                this.Close();
            }
        }
    }
}
